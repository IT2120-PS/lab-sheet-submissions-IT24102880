# Ex 01 Probability train arrives between 10 and 25 minutes
punif(25, min=0, max=40) - punif(10, min=0, max=40)


# Ex 02 
lambda <- 1/3

pexp(2, rate=lambda)


# Ex 03
mu <- 100
sigma <- 15

1-  pnorm(130, mean=mu, sd=sigma)

qnorm(0.95, mean=mu, sd=sigma)