setwd("C:\\Users\\IT24102880\\Downloads\\Lab 08-20250926")

data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)

#  Population Mean and Standard Deviation
pop_mean <- mean(weights)
pop_sd <- sd(weights)

cat("Population Mean:", pop_mean, "\n")
cat("Population SD:", pop_sd, "\n")

#  Draw 25 samples of size 6 (with replacement)
set.seed(123)  # For reproducibility
sample_means <- c()
sample_sds <- c()

for (i in 1:25) {
  sample_i <- sample(weights, 6, replace = TRUE)
  sample_means <- c(sample_means, mean(sample_i))
  sample_sds <- c(sample_sds, sd(sample_i))
}

# Display sample means and standard deviations
cat("Sample Means:\n")
print(sample_means)
cat("Sample SDs:\n")
print(sample_sds)

#  Mean and SD of the 25 sample means
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("Mean of Sample Means:", mean_of_sample_means, "\n")
cat("SD of Sample Means:", sd_of_sample_means, "\n")


