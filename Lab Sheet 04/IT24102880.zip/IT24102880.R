setwd("C:\\Users\\IT24102880\\Documents\\Lab 04-20250822")

# 1. Import the dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

# 2. Identify variable types and scales
str(branch_data)  # Shows structure and types of each variable

# 3. Boxplot for Sales with minimal margins
par(mar = c(2, 2, 2, 1))  # Bottom, left, top, right margins
boxplot(branch_data$Sales_X1,
        main = "Sales",
        xlab = "",
        col = "lightblue",
        border = "darkblue")

# 4. Five number summary and IQR for Advertising
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

# 5. Function to find outliers in a numeric vector
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers in Years
find_outliers(branch_data$Years_X3)

# Optional: Check for outliers in other variables
find_outliers(branch_data$Sales_X1)
find_outliers(branch_data$Advertising_X2)





