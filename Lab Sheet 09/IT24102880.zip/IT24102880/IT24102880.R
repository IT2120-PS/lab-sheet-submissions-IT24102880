# Set working directory (replace with your actual path)
setwd("C:\Users\Kalhara.v1\Desktop\IT24102880")

# Exercise 2.i: Test whether the true mean weight of mice is less than 25g at 5% level of significance
weights <- c(17.6, 20.6, 22.2, 15.3, 20.9, 21.0, 18.9, 18.9, 18.9, 18.2)
t.test(weights, mu=25, alternative="less")

# Exercise 2.ii: Obtain the value of test statistic, p-value and confidence interval
res <- t.test(weights, mu=25, alternative="less")
res$statistic
res$p.value
res$conf.int